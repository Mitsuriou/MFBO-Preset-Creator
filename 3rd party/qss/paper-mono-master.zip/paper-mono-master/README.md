# Paper Mono

![](https://i.imgur.com/Jll0WEA.png)
![](https://staticdelivery.nexusmods.com/mods/110/images/64439/64439-1575343021-1979215660.png)
![](https://staticdelivery.nexusmods.com/mods/110/images/64439/64439-1575343022-94354463.png)

## Installation

Download and extract the archive (.7z) using 7-Zip and move all of the files and folders from the archive into Mod Organizer 2's stylesheets folder:

> <Where You Installed Mod Organizer 2>\stylesheets

## Usage

Click the Settings button on the top toolbar, select the theme from the Style dropdown menu and click OK to apply.
