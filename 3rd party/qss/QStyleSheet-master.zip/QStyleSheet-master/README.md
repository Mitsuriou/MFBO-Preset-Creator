## QStyleSheet

this is qss styles for qt 
